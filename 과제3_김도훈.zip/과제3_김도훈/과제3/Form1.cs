using System.Configuration;

namespace 과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
        }
        string number = "0";
        bool init = false;  //초기화,새로 쓰기 상태 false면 이어붙이기
        bool op = false; //false면 아무런 연산도 하지 않은 숫자 상태
        //bool first = true;

        private void button1_Click(object sender, EventArgs e)
        {
        }

       
        public void addNumber(string num)
        {
            if (init)
            {
                number = num;
                init = false;
                op = false;
            }
            else
            {
                number = (number == "0") ? num : number + num;
            }
            numText.Text = number;
            //opText.Text = number;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            addNumber("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addNumber("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addNumber("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            addNumber("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addNumber("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addNumber("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addNumber("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            addNumber("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            addNumber("9");
        }

        private void button0_Click(object sender, EventArgs e)
        {
            addNumber("0");
        }

        private void sign_button_Click(object sender, EventArgs e)
        {
            number = (-double.Parse(number)).ToString();
            numText.Text = number;
            if (op)
            {
                opText.Text = "negate(" + opText.Text + ")";
            }
        }

        private void pow_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "sqr(" + operand + ")";

            number = Math.Pow(double.Parse(number), 2).ToString();
            numText.Text = number.ToString();

            init = true;
            op = true;
        }

        private void route_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "sqrt(" + operand + ")";
            number = Math.Sqrt(double.Parse(number)).ToString();
            numText.Text = number.ToString();
            init = true;
            op = true;
        }

        private void rec_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "1/(" + operand + ")";
            number = (number == "0") ? numText.Text = "0으로 나눌 수 없습니다." : (1 / double.Parse(number)).ToString();
            numText.Text = number.ToString();
            init = true;
            op = true;
        }

        private void c_button_Click(object sender, EventArgs e)
        {
            number = "0";
            numText.Text = number;
            opText.Text = "";
            init = false;
            op = false;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
            {
                string num = (e.KeyCode - Keys.D0).ToString();
                addNumber(num);
            }
            else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
            {
                string num = (e.KeyCode - Keys.NumPad0).ToString();
                addNumber(num);
            }
            else if (e.KeyCode == Keys.Add)
            {
               
            }
            else if (e.KeyCode == Keys.Subtract)
            {
                
            }
            else if (e.KeyCode == Keys.Multiply)
            {
                
            }
            else if (e.KeyCode == Keys.Divide)
            {
                
            }
            else if (e.KeyCode == Keys.Back)
            {
                
            }
            else if (e.KeyCode == Keys.Enter)
            {
                
            }
            else if (e.KeyCode == Keys.Escape)
            {
                
            }
        }
        private void per_button_Click(object sender, EventArgs e)
        {
            double num = double.Parse(number) / 100;
            number = num.ToString();
            numText.Text = number;
            init = true;
        }
        private void ce_button_Click(object sender, EventArgs e)
        {
            
            numText.Text = "0";

        }
        string currentOp = "";
        double num = 0;
        private void div_button_Click(object sender, EventArgs e)
        {
            num = double.Parse(number);
            currentOp = "÷";
            opText.Text = num + " " + currentOp;
            init = true;
        }

        private void del_button_Click(object sender, EventArgs e)
        {
            if (init)
            {
                return; 
            }
            string currentText = numText.Text;
            if (currentText == "0" || string.IsNullOrEmpty(currentText))
                return;
            if (currentText.Length <= 1 || currentText.Contains("없습니다"))
            {
                number = "0";
            }
            else
            {
                
                number = currentText.Substring(0, currentText.Length - 1);
            }

           
            numText.Text = number;
        }

        private void mul_button_Click(object sender, EventArgs e)
        {
            num = double.Parse(number);
            currentOp = "x";
            opText.Text = num +" " + currentOp;
            init = true;
        }

        private void min_button_Click(object sender, EventArgs e)
        {
            num = double.Parse(number);
            currentOp = "-";
            opText.Text = num + " " + currentOp;
            init = true;
        }

        private void plus_button_Click(object sender, EventArgs e)
        {
            num = double.Parse(number);
            currentOp = "+";
            opText.Text = num + " " + currentOp;
            init = true;

         }

        private void eq_button_Click(object sender, EventArgs e)
        {
            double nextNum = double.Parse(number);
            double num = 0;

            string str = opText.Text;
            string[] words = str.Split(" ");
            if (words.Length < 2) return;
            num = double.Parse(words[0]);
            string opStr = words[1];
            switch (opStr)
            {
                case "+":
                    num = num + nextNum;
                    break;
                case "-":
                    num = num - nextNum;
                    break;
                case "x":
                    num = num * nextNum;
                    break;
                case "÷":
                    if (nextNum == 0)
                    {
                        numText.Text = "0으로 나눌 수 없습니다";
                        return;
                    }
                    else
                    {
                        num = num / nextNum;
                    }
                    break;
               
            }
            opText.Text = words[0] + " " + opStr + " " + nextNum + " =";
            number = num.ToString();
            numText.Text = number;
            init = true;
            op = false;
        }

        private void dot_button_Click(object sender, EventArgs e)
        {
            if (!number.Contains("."))
            {
                number += ".";
                numText.Text = number;
            }
        }
    }
}
