namespace 과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string number = "0";
        bool init = false;
        bool op = false;
        //bool first = true;

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void per_button_Click(object sender, EventArgs e)
        {

        }
        public void addNumber(string num)
        {
            if (init)
            {
                number = num;
                init = false;
                op = false;
            }
            else
            {
                number = (number == "0") ? num : number + num;
            }
            numText.Text = number;
            //opText.Text = number;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            addNumber("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addNumber("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addNumber("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            addNumber("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addNumber("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addNumber("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addNumber("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            addNumber("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            addNumber("9");
        }

        private void button0_Click(object sender, EventArgs e)
        {
            addNumber("0");
        }

        private void sign_button_Click(object sender, EventArgs e)
        {
            number = (-double.Parse(number)).ToString();
            numText.Text = number;
            if (op)
            {
                opText.Text = "negate(" + opText.Text + ")";
            }
        }

        private void pow_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "sqr(" + operand + ")";

            number = Math.Pow(double.Parse(number), 2).ToString();
            numText.Text = number.ToString();
            
            init = true;
            op = true;
        }

        private void route_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "sqrt(" + operand + ")";
            number = Math.Sqrt(double.Parse(number)).ToString();
            numText.Text = number.ToString();
            init = true;
            op = true;
        }

        private void rec_button_Click(object sender, EventArgs e)
        {
            string operand = op ? opText.Text : number;
            opText.Text = "1/(" + operand + ")";
            number = (number == "0") ? numText.Text = "0으로 나눌 수 없습니다." : (1 / double.Parse(number)).ToString();
            numText.Text = number.ToString();
            init = true;
            op = true;
        }

        private void c_button_Click(object sender, EventArgs e)
        {
            number = "0";
            numText.Text = number;
            opText.Text = "";
            init = false;
            op = false;
        }
    }
}
