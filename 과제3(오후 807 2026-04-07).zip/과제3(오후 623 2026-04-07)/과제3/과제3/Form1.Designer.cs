﻿namespace 과제3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            menu_button = new Button();
            panel2 = new Panel();
            numText = new TextBox();
            opText = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            eq_button = new Button();
            dot_button = new Button();
            button0 = new Button();
            sign_button = new Button();
            plus_button = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            min_button = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            mul_button = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            div_button = new Button();
            route_button = new Button();
            pow_button = new Button();
            rec_button = new Button();
            del_button = new Button();
            c_button = new Button();
            ce_button = new Button();
            per_button = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(menu_button);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(894, 96);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.MenuBar;
            label1.Dock = DockStyle.Left;
            label1.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(80, 0);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(84, 96);
            label1.TabIndex = 1;
            label1.Text = "표준";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // menu_button
            // 
            menu_button.BackColor = SystemColors.MenuBar;
            menu_button.Dock = DockStyle.Left;
            menu_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            menu_button.Location = new Point(0, 0);
            menu_button.Margin = new Padding(6);
            menu_button.Name = "menu_button";
            menu_button.Size = new Size(80, 96);
            menu_button.TabIndex = 0;
            menu_button.Text = "≡";
            menu_button.UseVisualStyleBackColor = false;
            menu_button.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(numText);
            panel2.Controls.Add(opText);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 96);
            panel2.Margin = new Padding(6);
            panel2.Name = "panel2";
            panel2.Size = new Size(894, 256);
            panel2.TabIndex = 1;
            // 
            // numText
            // 
            numText.BackColor = SystemColors.MenuBar;
            numText.BorderStyle = BorderStyle.None;
            numText.Dock = DockStyle.Fill;
            numText.Font = new Font("맑은 고딕", 48F, FontStyle.Regular, GraphicsUnit.Point, 129);
            numText.Location = new Point(0, 56);
            numText.Margin = new Padding(6);
            numText.Name = "numText";
            numText.Size = new Size(894, 171);
            numText.TabIndex = 1;
            numText.Text = "0";
            numText.TextAlign = HorizontalAlignment.Right;
            // 
            // opText
            // 
            opText.BackColor = SystemColors.MenuBar;
            opText.BorderStyle = BorderStyle.None;
            opText.Dock = DockStyle.Top;
            opText.Font = new Font("맑은 고딕", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 129);
            opText.Location = new Point(0, 0);
            opText.Margin = new Padding(6);
            opText.Name = "opText";
            opText.Size = new Size(894, 56);
            opText.TabIndex = 0;
            opText.TextAlign = HorizontalAlignment.Right;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(eq_button, 3, 5);
            tableLayoutPanel1.Controls.Add(dot_button, 2, 5);
            tableLayoutPanel1.Controls.Add(button0, 1, 5);
            tableLayoutPanel1.Controls.Add(sign_button, 0, 5);
            tableLayoutPanel1.Controls.Add(plus_button, 3, 4);
            tableLayoutPanel1.Controls.Add(button3, 2, 4);
            tableLayoutPanel1.Controls.Add(button2, 1, 4);
            tableLayoutPanel1.Controls.Add(button1, 0, 4);
            tableLayoutPanel1.Controls.Add(min_button, 3, 3);
            tableLayoutPanel1.Controls.Add(button6, 2, 3);
            tableLayoutPanel1.Controls.Add(button5, 1, 3);
            tableLayoutPanel1.Controls.Add(button4, 0, 3);
            tableLayoutPanel1.Controls.Add(mul_button, 3, 2);
            tableLayoutPanel1.Controls.Add(button9, 2, 2);
            tableLayoutPanel1.Controls.Add(button8, 1, 2);
            tableLayoutPanel1.Controls.Add(button7, 0, 2);
            tableLayoutPanel1.Controls.Add(div_button, 3, 1);
            tableLayoutPanel1.Controls.Add(route_button, 2, 1);
            tableLayoutPanel1.Controls.Add(pow_button, 1, 1);
            tableLayoutPanel1.Controls.Add(rec_button, 0, 1);
            tableLayoutPanel1.Controls.Add(del_button, 3, 0);
            tableLayoutPanel1.Controls.Add(c_button, 2, 0);
            tableLayoutPanel1.Controls.Add(ce_button, 1, 0);
            tableLayoutPanel1.Controls.Add(per_button, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 352);
            tableLayoutPanel1.Margin = new Padding(6);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.Size = new Size(894, 966);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // eq_button
            // 
            eq_button.Dock = DockStyle.Fill;
            eq_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            eq_button.Location = new Point(675, 811);
            eq_button.Margin = new Padding(6);
            eq_button.Name = "eq_button";
            eq_button.Size = new Size(213, 149);
            eq_button.TabIndex = 23;
            eq_button.Text = "=";
            eq_button.UseVisualStyleBackColor = true;
            // 
            // dot_button
            // 
            dot_button.Dock = DockStyle.Fill;
            dot_button.Font = new Font("맑은 고딕", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            dot_button.Location = new Point(452, 811);
            dot_button.Margin = new Padding(6);
            dot_button.Name = "dot_button";
            dot_button.Size = new Size(211, 149);
            dot_button.TabIndex = 22;
            dot_button.Text = ".";
            dot_button.UseVisualStyleBackColor = true;
            // 
            // button0
            // 
            button0.Dock = DockStyle.Fill;
            button0.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button0.Location = new Point(229, 811);
            button0.Margin = new Padding(6);
            button0.Name = "button0";
            button0.Size = new Size(211, 149);
            button0.TabIndex = 21;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = true;
            button0.Click += button0_Click;
            // 
            // sign_button
            // 
            sign_button.Dock = DockStyle.Fill;
            sign_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            sign_button.Location = new Point(6, 811);
            sign_button.Margin = new Padding(6);
            sign_button.Name = "sign_button";
            sign_button.Size = new Size(211, 149);
            sign_button.TabIndex = 20;
            sign_button.Text = "+/-";
            sign_button.UseVisualStyleBackColor = true;
            sign_button.Click += sign_button_Click;
            // 
            // plus_button
            // 
            plus_button.Dock = DockStyle.Fill;
            plus_button.Font = new Font("맑은 고딕", 18F, FontStyle.Regular, GraphicsUnit.Point, 129);
            plus_button.Location = new Point(675, 650);
            plus_button.Margin = new Padding(6);
            plus_button.Name = "plus_button";
            plus_button.Size = new Size(213, 149);
            plus_button.TabIndex = 19;
            plus_button.Text = "+";
            plus_button.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Fill;
            button3.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button3.Location = new Point(452, 650);
            button3.Margin = new Padding(6);
            button3.Name = "button3";
            button3.Size = new Size(211, 149);
            button3.TabIndex = 18;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Fill;
            button2.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button2.Location = new Point(229, 650);
            button2.Margin = new Padding(6);
            button2.Name = "button2";
            button2.Size = new Size(211, 149);
            button2.TabIndex = 17;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Fill;
            button1.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button1.Location = new Point(6, 650);
            button1.Margin = new Padding(6);
            button1.Name = "button1";
            button1.Size = new Size(211, 149);
            button1.TabIndex = 16;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // min_button
            // 
            min_button.Dock = DockStyle.Fill;
            min_button.Font = new Font("맑은 고딕", 18F, FontStyle.Regular, GraphicsUnit.Point, 129);
            min_button.Location = new Point(675, 489);
            min_button.Margin = new Padding(6);
            min_button.Name = "min_button";
            min_button.Size = new Size(213, 149);
            min_button.TabIndex = 15;
            min_button.Text = "-";
            min_button.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Dock = DockStyle.Fill;
            button6.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button6.Location = new Point(452, 489);
            button6.Margin = new Padding(6);
            button6.Name = "button6";
            button6.Size = new Size(211, 149);
            button6.TabIndex = 14;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Dock = DockStyle.Fill;
            button5.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button5.Location = new Point(229, 489);
            button5.Margin = new Padding(6);
            button5.Name = "button5";
            button5.Size = new Size(211, 149);
            button5.TabIndex = 13;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Dock = DockStyle.Fill;
            button4.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button4.Location = new Point(6, 489);
            button4.Margin = new Padding(6);
            button4.Name = "button4";
            button4.Size = new Size(211, 149);
            button4.TabIndex = 12;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // mul_button
            // 
            mul_button.Dock = DockStyle.Fill;
            mul_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            mul_button.Location = new Point(675, 328);
            mul_button.Margin = new Padding(6);
            mul_button.Name = "mul_button";
            mul_button.Size = new Size(213, 149);
            mul_button.TabIndex = 11;
            mul_button.Text = "X";
            mul_button.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Dock = DockStyle.Fill;
            button9.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button9.Location = new Point(452, 328);
            button9.Margin = new Padding(6);
            button9.Name = "button9";
            button9.Size = new Size(211, 149);
            button9.TabIndex = 10;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.Dock = DockStyle.Fill;
            button8.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button8.Location = new Point(229, 328);
            button8.Margin = new Padding(6);
            button8.Name = "button8";
            button8.Size = new Size(211, 149);
            button8.TabIndex = 9;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button7
            // 
            button7.Dock = DockStyle.Fill;
            button7.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            button7.Location = new Point(6, 328);
            button7.Margin = new Padding(6);
            button7.Name = "button7";
            button7.Size = new Size(211, 149);
            button7.TabIndex = 8;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // div_button
            // 
            div_button.Dock = DockStyle.Fill;
            div_button.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            div_button.Location = new Point(675, 167);
            div_button.Margin = new Padding(6);
            div_button.Name = "div_button";
            div_button.Size = new Size(213, 149);
            div_button.TabIndex = 7;
            div_button.Text = "÷";
            div_button.UseVisualStyleBackColor = true;
            // 
            // route_button
            // 
            route_button.Dock = DockStyle.Fill;
            route_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            route_button.Location = new Point(452, 167);
            route_button.Margin = new Padding(6);
            route_button.Name = "route_button";
            route_button.Size = new Size(211, 149);
            route_button.TabIndex = 6;
            route_button.Text = "²√x";
            route_button.UseVisualStyleBackColor = true;
            route_button.Click += route_button_Click;
            // 
            // pow_button
            // 
            pow_button.Dock = DockStyle.Fill;
            pow_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            pow_button.Location = new Point(229, 167);
            pow_button.Margin = new Padding(6);
            pow_button.Name = "pow_button";
            pow_button.Size = new Size(211, 149);
            pow_button.TabIndex = 5;
            pow_button.Text = "x²";
            pow_button.UseVisualStyleBackColor = true;
            pow_button.Click += pow_button_Click;
            // 
            // rec_button
            // 
            rec_button.Dock = DockStyle.Fill;
            rec_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            rec_button.Location = new Point(6, 167);
            rec_button.Margin = new Padding(6);
            rec_button.Name = "rec_button";
            rec_button.Size = new Size(211, 149);
            rec_button.TabIndex = 4;
            rec_button.Text = "1/x";
            rec_button.UseVisualStyleBackColor = true;
            rec_button.Click += rec_button_Click;
            // 
            // del_button
            // 
            del_button.Dock = DockStyle.Fill;
            del_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            del_button.Location = new Point(675, 6);
            del_button.Margin = new Padding(6);
            del_button.Name = "del_button";
            del_button.Size = new Size(213, 149);
            del_button.TabIndex = 3;
            del_button.Text = "⌫";
            del_button.UseVisualStyleBackColor = true;
            // 
            // c_button
            // 
            c_button.Dock = DockStyle.Fill;
            c_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            c_button.Location = new Point(452, 6);
            c_button.Margin = new Padding(6);
            c_button.Name = "c_button";
            c_button.Size = new Size(211, 149);
            c_button.TabIndex = 2;
            c_button.Text = "C";
            c_button.UseVisualStyleBackColor = true;
            c_button.Click += c_button_Click;
            // 
            // ce_button
            // 
            ce_button.Dock = DockStyle.Fill;
            ce_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            ce_button.Location = new Point(229, 6);
            ce_button.Margin = new Padding(6);
            ce_button.Name = "ce_button";
            ce_button.Size = new Size(211, 149);
            ce_button.TabIndex = 1;
            ce_button.Text = "CE";
            ce_button.UseVisualStyleBackColor = true;
            // 
            // per_button
            // 
            per_button.Dock = DockStyle.Fill;
            per_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            per_button.Location = new Point(6, 6);
            per_button.Margin = new Padding(6);
            per_button.Name = "per_button";
            per_button.Size = new Size(211, 149);
            per_button.TabIndex = 0;
            per_button.Text = "%";
            per_button.UseVisualStyleBackColor = true;
            per_button.Click += per_button_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(894, 1318);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button menu_button;
        private Panel panel2;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private TextBox numText;
        private TextBox opText;
        private Button eq_button;
        private Button dot_button;
        private Button button0;
        private Button sign_button;
        private Button plus_button;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button min_button;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button mul_button;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button div_button;
        private Button route_button;
        private Button pow_button;
        private Button rec_button;
        private Button del_button;
        private Button c_button;
        private Button ce_button;
        private Button per_button;
    }
}
