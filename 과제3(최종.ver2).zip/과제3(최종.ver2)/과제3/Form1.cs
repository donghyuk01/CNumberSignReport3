using System.ComponentModel.DataAnnotations;

namespace 과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
        }
        string number = "0";
        bool init = false;
        bool op = false;
        bool save; // 사칙연산 변경
        bool save2=false; //퍼센트 조건 초기화
        bool save3=false;//사칙연산후 버튼 클릭 초기화
        bool sb = false;
        bool save4 = false;
        bool save5 = false;
        string remember;
        //private void button1_Click(object sender, EventArgs e)
        //{
        //}
        public void CGB() {
            sign_button.BackColor = Color.Gray;
            pow_button.BackColor = Color.Gray;
            per_button.BackColor = Color.Gray;
            dot_button.BackColor = Color.Gray;
            rec_button.BackColor = Color.Gray;
            route_button.BackColor = Color.Gray;
            plus_button.BackColor = Color.Gray;
            min_button.BackColor = Color.Gray;
            mul_button.BackColor = Color.Gray;
            div_button.BackColor = Color.Gray;
        }
        public void CWB() {
            sign_button.BackColor = Color.White;
            pow_button.BackColor = Color.White;
            per_button.BackColor = Color.White;
            dot_button.BackColor = Color.White;
            rec_button.BackColor = Color.White;
            route_button.BackColor = Color.White;
            plus_button.BackColor = Color.White;
            min_button.BackColor = Color.White;
            mul_button.BackColor = Color.White;
            div_button.BackColor = Color.White;
        }

        public void addNumber(string num, object sender, EventArgs e)
        {
            if (save4)
            {
                number = "0";
                save5 = true;
            }
            if (save2)
                opText.Text = remember;
            if (save3)
            {
                numText.Text = "";
                number = "";
                save3 = false;
            }
            save2 = false;
            if (init)
            {
                number = num;
                init = false;
                op = false;
            }
            else
            {
                number = (number == "0") ? num : number + num;
                save = false;
            }
            numText.Text = number;
            //opText.Text = number;
            if (sb) {
                CWB();
                sb = false;
                c_button_Click(sender, e);
            }
        }
        public bool checkAO() {
            if (opText.Text.Contains("+"))
                return true;
            else if (opText.Text.Contains("-"))
                return true;
            else if (opText.Text.Contains("x"))
                return true;
            else if (opText.Text.Contains("÷"))
                return true;
            else
                return false;
        }
        public void getAO()
        {
            if (string.IsNullOrEmpty(opText.Text))
                return;

            if (opText.Text.Contains("="))
                return;

            string step = opText.Text.Remove(opText.Text.Length - 1);   

            if (opText.Text.Contains("+"))
            {
                string[] parts = step.Split('+');
                double a = double.Parse(parts[0]);
                double b = double.Parse(number);
                number = (a + b).ToString();
            }
            else if (opText.Text.Contains("-"))
            {
                string[] parts = step.Split('-');
                double a = double.Parse(parts[0]);
                double b = double.Parse(number);
                number = (a - b).ToString();
            }
            else if (opText.Text.Contains("x"))
            {
                string[] parts = step.Split('x');
                double a = double.Parse(parts[0]);
                double b = double.Parse(number);
                number = (a * b).ToString();
            }
            else if (opText.Text.Contains("÷"))
            {
                string[] parts = step.Split('÷');
                double a = double.Parse(parts[0]);
                double b = double.Parse(number);

                if (b == 0)
                {
                    numText.Text = "0으로 나눌 수 없습니다.";
                    sb = true;
                    CGB();
                    return;
                }

                number = (a / b).ToString();
            }

            //opText.Text = number;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {

            addNumber("1",sender, e);
            save = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addNumber("2", sender, e);
            save = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addNumber("3", sender, e);
            save = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            addNumber("4", sender, e);
            save = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addNumber("5", sender, e);
            save = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addNumber("6", sender, e);
            save = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addNumber("7", sender, e);
            save = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            addNumber("8", sender, e);
            save = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            addNumber("9", sender, e);
            save = false;
        }

        private void button0_Click(object sender, EventArgs e)
        {
            addNumber("0", sender, e);
            save = false;
        }
        
        private void sign_button_Click(object sender, EventArgs e)
        {
            if (sb) 
                return;
            number = (-double.Parse(number)).ToString();
            numText.Text = number;
            if (op)
            {
                opText.Text = "negate(" + opText.Text + ")";
            }
            save = false;
            save4 = true;
        }

        private void pow_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            string operand = op ? opText.Text : number;
            opText.Text = "sqr(" + operand + ")";

            number = Math.Pow(double.Parse(number), 2).ToString();
            numText.Text = number.ToString();

            init = true;
            op = true;
            save = false;
            save4 = true;
        }

        private void route_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            string operand = op ? opText.Text : number;
            opText.Text = "√(" + operand + ")";
            number = Math.Sqrt(double.Parse(number)).ToString();
            numText.Text = number.ToString();
            init = true;
            op = true;
            save = false;
            save4 = true;
        }

        private void rec_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            string operand = op ? opText.Text : number;
            opText.Text = "1/(" + operand + ")";
            //number = (number == "0") ? numText.Text = "0으로 나눌 수 없습니다." : (1 / double.Parse(number)).ToString();
            if (double.Parse(number) == 0)
            {
                numText.Text = "0으로 나눌 수 없습니다.";
                sb = true;
                CGB();
            }
            else
            {
                number = (1 / double.Parse(number)).ToString();
                numText.Text = number.ToString();
            }
            init = true;
            op = true;
            save = false;
            save4 = true;
        }
        
        private void c_button_Click(object sender, EventArgs e)
        {

            if (sb)
            {
                CWB();
                sb = false;
            }
            number = "0";
            numText.Text = number;
            opText.Text = "";
            init = false;
            op = false;
            save4 = false;
        }
        private void dot_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            
            if (!number.Contains(".")) {
                number += ".";
                numText.Text = number;
                save = false;
            }
            if (save4)
            {
                number = "0.";
                save4 = false;
                numText.Text = number;
            }
        }
        private void per_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(opText.Text))
                return;

            if (sb)
                return;

            double current = double.Parse(number);

            // "=" 이후 또는 opText 없을 때 → 그냥 % 처리
            if (string.IsNullOrEmpty(opText.Text) || opText.Text.Contains("="))
            {
                double result = current * (current / 100.0);

                number = result.ToString();
                numText.Text = number;
                opText.Text = number;
                return;
            }

            // 연산식에서 첫 번째 값 추출
            string expr = opText.Text.Remove(opText.Text.Length - 1);

            double baseVal = 0;

            if (expr.Contains("+"))
                baseVal = double.Parse(expr.Split('+')[0]);
            else if (expr.Contains("-"))
                baseVal = double.Parse(expr.Split('-')[0]);
            else if (expr.Contains("x"))
                baseVal = double.Parse(expr.Split('x')[0]);
            else if (expr.Contains("÷"))
                baseVal = double.Parse(expr.Split('÷')[0]);
            else
                baseVal = double.Parse(expr);

            // 연산별 퍼센트 처리
            if (opText.Text.Contains("+"))
            {
                double percentVal = baseVal * current / 100.0;
                number = percentVal.ToString();
                numText.Text = number;
                opText.Text = baseVal + "+" + number;
            }
            else if (opText.Text.Contains("-"))
            {
                double percentVal = baseVal * current / 100.0;
                number = percentVal.ToString();
                numText.Text = number;
                opText.Text = baseVal + "-" + number;
            }
            else if (opText.Text.Contains("x"))
            {
                double percentVal = current / 100.0;
                number = percentVal.ToString();
                numText.Text = number;
                opText.Text = baseVal + "x" + number;
            }
            else if (opText.Text.Contains("÷"))
            {
                double percentVal = current / 100.0;

                if (percentVal == 0)
                {
                    numText.Text = "0으로 나눌 수 없습니다.";
                    sb = true;
                    CGB();
                    return;
                }

                number = percentVal.ToString();
                numText.Text = number;
                opText.Text = baseVal + "÷" + number;
            }

            save2 = false;
        }

        private void ce_button_Click(object sender, EventArgs e)
        {
            if (sb)
            {
                CWB();
                sb = false;
                c_button_Click(sender, e);
            }
            number = "0";
            numText.Text = number;
            save = false;
            save4 = false;
        }

        private void del_button_Click(object sender, EventArgs e)
        {
            if (sb)
            {
                CWB();
                sb = false;
                c_button_Click(sender, e);
            }
            if (number.Length > 1)
            {
                // number = number.Substring(0, number.Length - 1); //범위 지정
                // number = number[0..^1]; // 처음부터 끝에서 첫번째 문자전까지
            }
            else
            {
                number = "0";
            }

            numText.Text = number;
            save = false;
        }

        private void div_button_Click(object sender, EventArgs e)
        {

            if (sb)
                return;
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "÷";
                save = false;
                return;
            }
            if (save4 && save5)
            {
                number = numText.Text;
                opText.Text = number + "÷";
                save4 = false;
                save5= false;
            }
            if (!save)
            {
                getAO();
                save = true;
            }
            if (opText.Text.Contains("=")) {
                opText.Text = number+ "÷";
            }
            //else if (checkAO())
            //    opText.Text = opText.Text.Remove(opText.Text.Length - 1) + "÷";
            else
                opText.Text = number + "÷";
            save3 = true;
        }

        private void mul_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "x";
                save = false;
                return;
            }
            if (save4 && save5)
            {
                number = numText.Text;
                opText.Text = number + "x";
                save4 = false;
                save5 = false;
            }
            if (!save)
            {
                getAO();
                save = true;
            }
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "x";
            }
            //else if (checkAO())
            //    opText.Text = opText.Text.Remove(opText.Text.Length - 1) + "x";
            else
                opText.Text = number + "x";
            save3 = true;
        }

        private void min_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return; // 멈추기
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "-";
                save = false;
                return;
            }
            if (save4 && save5)
            {
                number = numText.Text;
                opText.Text = number + "-";
                save4 = false;
                save5 = false;
            }
            if (!save)
            {
                getAO();  //계산
                save = true;  // 사칙연산 눌렀는지 감지
            }
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "-";
            }
            //else if (checkAO())
            //    opText.Text = opText.Text.Remove(opText.Text.Length - 1) + "-";
            else
                opText.Text = number + "-";
            save3 = true;
        }

        private void plus_button_Click(object sender, EventArgs e)
        {
            if (sb)
                return;
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "+";
                save = false;
                return;
            }
            if (save4 && save5)
            {
                number = numText.Text;
                opText.Text = number + "+";
                save4 = false;
                save5 = false;
            }
            if (!save)
            {
                getAO();
                save = true;
            }
            if (opText.Text.Contains("="))
            {
                opText.Text = number + "+";
            }
            //else if (checkAO())
            //{
            //    opText.Text=number + "+";
            //}
            //opText.Text = opText.Text.Remove(opText.Text.Length - 1) + "+";
            else
                opText.Text = number + "+";
            save3 = true;
        }

        private void eq_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(opText.Text))
                return;

            if (sb)
            {
                CWB();
                sb = false;
                c_button_Click(sender, e);
            }
            string expr = opText.Text + number;

            getAO();
            if (!opText.Text.Contains("="))
            {
                opText.Text = expr + "=";
                numText.Text = number;
            }

            else if(checkAO()){
                if (opText.Text.Contains("+"))
                {
                    string temp = opText.Text.Substring(opText.Text.IndexOf('+')+1);
                    opText.Text = number + "+" + temp;
                    temp =temp.Replace("=","");
                    number= (double.Parse(number)+double.Parse(temp)).ToString();
                    numText.Text = number;
                }
                else if (opText.Text.Contains("-"))
                {
                    string temp = opText.Text.Substring(opText.Text.IndexOf('-')+1);
                    opText.Text = number + "-" + temp;
                    temp = temp.Replace("=", "");
                    number = (double.Parse(number) - double.Parse(temp)).ToString();         
                    numText.Text = number;
                }
                else if (opText.Text.Contains("x"))
                {
                    string temp = opText.Text.Substring(opText.Text.IndexOf('x')+1);
                    opText.Text = number + "x" + temp;
                    temp = temp.Replace("=", "");
                    number = (double.Parse(number) * double.Parse(temp)).ToString();
                    numText.Text = number;
                }
                else if (opText.Text.Contains("÷"))
                {
                    string temp = opText.Text.Substring(opText.Text.IndexOf('÷')+1);
                    temp = temp.Replace("=", "");
                    opText.Text = number + "÷" + temp;

                    double divisor = double.Parse(temp);
                    if (divisor == 0)
                    {
                        numText.Text = "0으로 나눌 수 없습니다.";
                        sb = true;
                        CGB();
                        return;
                    }
                    number = (double.Parse(number) / divisor).ToString();

                    numText.Text = number;
                }
                
            }

            save = false;
            save3 = true;
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
            {
                string num = (e.KeyCode - Keys.D0).ToString();
                addNumber(num, sender, e);
                save = false;
            }
            else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
            {
                string num = (e.KeyCode - Keys.NumPad0).ToString();
                addNumber(num, sender, e);
                save = false;
            }
            else if (e.KeyCode == Keys.Subtract) //  숫자 패드 -
            {
                min_button_Click(sender,e);
            }
            else if (e.KeyCode == Keys.OemMinus) //   -
            {
                min_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Multiply) // 숫자패드 *
            {
                mul_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Oem8 && e.Shift) //  *
            {
                mul_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Divide) // 숫자패드 /
            {
                div_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.OemQuestion) //  /
            {
                div_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Back) // 백스패이스
            {
                del_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Enter|| e.KeyCode == Keys.Space) // 엔터+ 숫자패드 엔터
            {
                eq_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Add) // 숫자패드 +
            {
                plus_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Oemplus && e.Shift) // 메인 키보드 Shift + =
            {
                plus_button_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Oemplus && !e.Shift) // 그냥 '=' 키
            {
                eq_button_Click(sender, e);
            }

        }


    }
}
