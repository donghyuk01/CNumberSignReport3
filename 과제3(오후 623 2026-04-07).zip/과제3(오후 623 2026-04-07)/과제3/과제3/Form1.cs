namespace 과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double number = 0;
        bool first = true;

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void per_button_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            number *= 10;
            number += 1;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 2;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 3;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 4;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 5;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 6;
            numText.Text = number.ToString();
            opText.Text = number.ToString();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 7;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 8;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            number *= 10;
            number += 9;
            numText.Text = number.ToString();
            opText.Text = number.ToString();
        }

        private void button0_Click(object sender, EventArgs e)
        {
            if (int.Parse(numText.Text)!=0)
            {
                number *= 10;
                numText.Text = number.ToString();
                opText.Text = number.ToString();
            }
        }
    }
}
